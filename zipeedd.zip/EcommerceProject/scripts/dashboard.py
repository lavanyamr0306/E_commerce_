import streamlit as st
import pandas as pd
import plotly.express as px

# -----------------------------
# Page Config
# -----------------------------
st.set_page_config(page_title="E-Commerce Monitoring Dashboard", layout="wide")
st.title("📊 E-Commerce Monitoring Dashboard")

# -----------------------------
# Step 1: Upload log file
# -----------------------------
uploaded_file = st.file_uploader("Upload your log CSV file", type=["csv"])

if uploaded_file is not None:
    logs = pd.read_csv(uploaded_file)
    
    # -----------------------------
    # Safety checks
    # -----------------------------
    required_columns = ['timestamp', 'region', 'device_type', 'product_id', 'ip_address', 'event_type', 'login_status', 'response_time']
    missing_cols = [col for col in required_columns if col not in logs.columns]
    if missing_cols:
        st.error(f"❌ Missing required columns: {', '.join(missing_cols)}")
        st.stop()

    # Parse timestamp safely
    logs['timestamp'] = pd.to_datetime(logs['timestamp'], errors='coerce')
    logs = logs.dropna(subset=['timestamp'])
    st.success(f"✅ File uploaded successfully! Total rows: {logs.shape[0]}")

    # -----------------------------
    # Sidebar Filters
    # -----------------------------
    st.sidebar.header("Filters")
    # Date filter
    min_date = logs['timestamp'].min().date()
    max_date = logs['timestamp'].max().date()
    start_date, end_date = st.sidebar.date_input("Select Date Range", [min_date, max_date])
    
    # Region filter
    regions = sorted(logs['region'].dropna().unique())
    selected_region = st.sidebar.multiselect("Select Region", options=regions, default=regions)

    # Device type filter
    devices = sorted(logs['device_type'].dropna().unique())
    selected_device = st.sidebar.multiselect("Select Device Type", options=devices, default=devices)

    # Apply filters
    filtered_logs = logs[
        (logs['region'].isin(selected_region)) &
        (logs['device_type'].isin(selected_device)) &
        (logs['timestamp'].dt.date >= start_date) &
        (logs['timestamp'].dt.date <= end_date)
    ]

    # -----------------------------
    # Anomaly thresholds
    # -----------------------------
    st.sidebar.subheader("Anomaly Thresholds")
    ddos_threshold = st.sidebar.number_input("DDoS Total Requests >", value=30, min_value=1)
    login_failure_threshold = st.sidebar.number_input("Failed Logins >", value=5, min_value=1)
    high_response_threshold = st.sidebar.number_input("Avg Response Time >", value=3.0, min_value=0.1)

    # -----------------------------
    # Analysis Type
    # -----------------------------
    analysis_type = st.radio("Select analysis type", ["Trending Products", "Anomalies & Recommendations"])

    # -----------------------------
    # Trending Products
    # -----------------------------
    if analysis_type == "Trending Products":
        st.header("🔥 Top Trending Products")
        top_n = st.slider("Select top N products", min_value=5, max_value=20, value=10)

        # Count events per product
        product_counts = filtered_logs['product_id'].value_counts().reset_index()
        product_counts.columns = ['product_id', 'count']

        st.table(product_counts.head(top_n))

        # Bar chart
        fig = px.bar(
            product_counts.head(top_n),
            x='product_id',
            y='count',
            title=f"Top {top_n} Trending Products",
            labels={'product_id': 'Product ID', 'count': 'Number of Events'},
            text='count'
        )
        st.plotly_chart(fig, use_container_width=True)

        # Download CSV
        st.download_button(
            label="Download Trending Products CSV",
            data=product_counts.head(top_n).to_csv(index=False).encode('utf-8'),
            file_name='trending_products.csv',
            mime='text/csv'
        )

    # -----------------------------
    # Anomalies & Recommendations
    # -----------------------------
    elif analysis_type == "Anomalies & Recommendations":
        st.header("🚨 Anomaly Detection & Recommendations")

        # Aggregate per IP
        agg = filtered_logs.groupby('ip_address').agg({
            'event_type': 'count',
            'login_status': lambda x: (x == 'failure').sum(),
            'response_time': 'mean'
        }).rename(columns={
            'event_type': 'total_requests',
            'login_status': 'failed_logins',
            'response_time': 'avg_response_time'
        })

        # Classify anomalies
        def classify_anomaly(row):
            if row['total_requests'] > ddos_threshold:
                return 'DDoS Attack', 'Block IP Immediately'
            elif row['failed_logins'] > login_failure_threshold:
                return 'Brute Force Login', 'Block IP / Alert Admin'
            elif row['avg_response_time'] > high_response_threshold:
                return 'High Response Time', 'Investigate Server / Optimize'
            else:
                return None, None

        agg[['anomaly_name', 'recommendation']] = agg.apply(lambda x: pd.Series(classify_anomaly(x)), axis=1)
        anomaly_report = agg.dropna(subset=['anomaly_name']).reset_index()

        # Summary metrics
        st.subheader("📊 Summary Metrics")
        st.metric("Total Requests", filtered_logs.shape[0])
        st.metric("Total Anomalies Detected", anomaly_report.shape[0])
        blocked_ips = anomaly_report[anomaly_report['anomaly_name'].isin(['DDoS Attack', 'Brute Force Login'])]
        st.metric("Blocked IPs", blocked_ips.shape[0])

        st.subheader("All Anomalies")
        st.dataframe(anomaly_report)

        # Blocked IPs section
        st.subheader("⛔ Blocked IPs")
        st.dataframe(blocked_ips[['ip_address', 'anomaly_name', 'recommendation']])

        # -----------------------------
        # Anomaly Visualization
        # -----------------------------
        agg_anomaly = anomaly_report.groupby(['ip_address', 'anomaly_name']).size().reset_index(name='count')
        fig_anomaly = px.bar(
            agg_anomaly,
            x='ip_address',
            y='count',
            color='anomaly_name',
            hover_data=['anomaly_name'],
            title="Detected Anomalies by IP (Stacked by Type)",
            labels={'ip_address': 'IP Address', 'count': 'Number of Anomalies'}
        )
        st.plotly_chart(fig_anomaly, use_container_width=True)

        # Download CSVs
        st.download_button(
            label="Download Anomalies CSV",
            data=anomaly_report.to_csv(index=False).encode('utf-8'),
            file_name='anomalies_report.csv',
            mime='text/csv'
        )
        st.download_button(
            label="Download Blocked IPs CSV",
            data=blocked_ips.to_csv(index=False).encode('utf-8'),
            file_name='blocked_ips.csv',
            mime='text/csv'
        )
